package com.bms.biller_service.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bms.biller_service.entity.BillerCategory;
import com.bms.biller_service.repository.BillerCategoryRepository;

@Service
public class BillerCategoryService {

    @Autowired
    private BillerCategoryRepository billerCategoryRepository;

    public List<BillerCategory> getAllBillerCategories() {
        return billerCategoryRepository.findAll();
    }

    public BillerCategory saveBillerCategory(BillerCategory billerCategory) {
        return billerCategoryRepository.save(billerCategory);
    }

    public void deleteBillerCategory(Long billerCategoryId) {
        billerCategoryRepository.deleteById(billerCategoryId);
    }
}
