package com.bms.npbi_service.service;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class NpbiService {

    public Mono<String> fetchBillDetails(Map<String, Object> requestPayload) {
        // Log requestReferenceId in service layer
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (NPBI Service): " + requestReferenceId);

        // Logic to process bill details and return response
        // Example:
        return Mono.just("Bill details for accountId: " + requestPayload.get("accountId"));
    }

    public Mono<String> fetchPlanDetails(Map<String, Object> requestPayload) {
        // Log requestReferenceId in service layer
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (NPBI Service): " + requestReferenceId);

        // Logic to process plan details and return response
        // Example:
        return Mono.just("Plan details for planId: " + requestPayload.get("planId"));
    }
}
