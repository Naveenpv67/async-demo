package com.bms.biller_service.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@Service
public class CouService {

    private final WebClient webClient;

    @Autowired
    public CouService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public Mono<String> fetchBillDetails(Map<String, Object> requestPayload) {
        // Log requestReferenceId in service layer
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (Service): " + requestReferenceId);

        // Logic to call NPBI service using WebClient and process response
        // Example:
        return webClient.post()
                .uri("/api/npbi/bill-details")
                .bodyValue(requestPayload)
                .retrieve()
                .bodyToMono(String.class);
    }

    public Mono<String> fetchPlanDetails(Map<String, Object> requestPayload) {
        // Log requestReferenceId in service layer
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (Service): " + requestReferenceId);

        // Logic to call NPBI service using WebClient and process response
        // Example:
        return webClient.post()
                .uri("/api/npbi/plan-details")
                .bodyValue(requestPayload)
                .retrieve()
                .bodyToMono(String.class);
    }
}
