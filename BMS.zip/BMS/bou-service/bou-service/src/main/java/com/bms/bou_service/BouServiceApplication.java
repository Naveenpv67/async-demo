package com.bms.bou_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BouServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BouServiceApplication.class, args);
	}

}
