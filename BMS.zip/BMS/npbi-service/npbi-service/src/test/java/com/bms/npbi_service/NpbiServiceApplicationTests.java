package com.bms.npbi_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NpbiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
