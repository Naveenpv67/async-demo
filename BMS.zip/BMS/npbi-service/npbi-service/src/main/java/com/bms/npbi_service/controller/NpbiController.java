package com.bms.npbi_service.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bms.npbi_service.service.NpbiService;

@RestController
@RequestMapping("/api/npbi")
public class NpbiController {

    @PostMapping("/bill-details")
    public Mono<String> fetchBillDetails(@RequestBody Map<String, Object> requestPayload) {
        // Log requestReferenceId in controller
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (NPBI Controller): " + requestReferenceId);

        // Call service layer
        NpbiService npbiService = new NpbiService();
        return npbiService.fetchBillDetails(requestPayload);
    }

    @PostMapping("/plan-details")
    public Mono<String> fetchPlanDetails(@RequestBody Map<String, Object> requestPayload) {
        // Log requestReferenceId in controller
        String requestReferenceId = (String) requestPayload.get("requestReferenceId");
        System.out.println("Request Reference ID (NPBI Controller): " + requestReferenceId);

        // Call service layer
        NpbiService npbiService = new NpbiService();
        return npbiService.fetchPlanDetails(requestPayload);
    }
}
