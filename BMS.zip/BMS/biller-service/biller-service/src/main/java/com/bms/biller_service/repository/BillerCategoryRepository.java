package com.bms.biller_service.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bms.biller_service.entity.BillerCategory;

public interface BillerCategoryRepository extends JpaRepository<BillerCategory, Long> {
}
