package com.bms.bou_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BouServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
